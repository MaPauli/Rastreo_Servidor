Descargar la base de datos y subirla a un servidor.
- Para modificar la ubicacion de la base de datos acceda al archivo: dbconnect.php
	
$dbuser = 'root';
$dbpass = '123456';
host=192.168.43.90;
dbname=gpstracker-09-14-14

Descargue la aplicacion de rastreo en el siguiente link.
https://play.google.com/store/apps/details?id=com.websmithing.gpstracker